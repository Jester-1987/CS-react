<?php

header("Content-Type: application/json");

request_once('../config/config.php');
request_once('../config/database.php');

// Define config options
$allowedMethods = ['GET'];
$maxPostsPerPage = 4;

// basic pagination
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$offest = ($page - 1) * $maxPostsPerPage;

// Query to count total posts
$countQuery = "SELECT COUNT(*) AS totalPosts FROM forum_posts";
$countResult = mysqli_query($conn, $countQuery);
$countRow = mysqli_fetch_assoc($countResult);
$totalPosts = $countRow['totalPosts'];

// Query to get all forum posts with pagination and ordering
$query = "SELECT * FROM forum_posts ORDER BY publish_date DESC LIMIT $offset, $maxPostsPerPage";
$result = mysqli_query($conn, $query);

//Check status of paginated posts query
if(!$result) {
    http_response_code(500); // internal server error
    echo json_encode(['message' => 'Error querying the database for paginated posts: ' . mysqli_error($conn)]);
    mysqli_close($conn);
    exit();

}

// convert query result into an associative array
$posts = mysqli_fetch_all($result, MYSQLI_ASSOC);

// check if there are posts
if (empty($posts)) {
    http_response_code(404); // not found
    echo json_encode(['message' => 'No posts found', 'totalPosts' => $totalPosts]);
}
else {
    http_response_code(200); // Ok
    echo json_encode(['posts' => $posts, 'totalPosts' => $totalPosts]);
}

// Close database connection
mysqli_close($conn);

?>

