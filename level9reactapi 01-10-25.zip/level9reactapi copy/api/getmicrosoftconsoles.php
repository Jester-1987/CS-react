<?php
header('Content-Type: application/json');

// Load configuration files
require_once('../config/config.php');
require_once('../config/database.php');

// Define configuration options
$allowedMethods = ['GET'];
$maxItemsPerPage = 10;

// Implement basic pagination
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$offset = ($page - 1) * $maxItemsPerPage;

// Query to count total items
$countQuery = "SELECT COUNT(*) AS totalItems FROM consoles WHERE manufacturer = 'Microsoft'";
$countResult = mysqli_query($conn, $countQuery);
$countRow = mysqli_fetch_assoc($countResult);
$totalItems = $countRow['totalItems'];

// check if total posts query is successful
if (!$countResult) {
    http_response_code(500);  // internal server error
    echo json_encode(['message' => 'Error querying database for total items count: ' . mysqli_error($conn)]);
    mysqli_close($conn);
    exit();
}

// query to get all items with pagination and ordering
$query = "SELECT * FROM consoles WHERE manufacturer = 'Microsoft' ORDER BY consoleReleaseYear DESC LIMIT $offset, $maxItemsPerPage";
$result = mysqli_query($conn, $query);

// check if total posts query is successful
if (!$result) {
    http_response_code(500); // internal server error
    echo json_encode(['message' => 'Error querying database for paginated items: ' . mysqli_error($conn)]);
    mysqli_close($conn);
    exit();
}

// convert query result into an associtative array
$consoles = mysqli_fetch_all($result, MYSQLI_ASSOC);

// check if there are items (if database gets deleted I guess?)
if (empty($consoles)) {
    http_response_code(400); // not found error
    echo json_encode(['message' => 'No posts found', 'totalItems' => $totalItems]);
}
else {
    // return JSON response including totalItems
    echo json_encode(['posts' => $consoles, 'totalItems' => $totalItems]);
}

// close database connection
mysqli_close($conn);

?>