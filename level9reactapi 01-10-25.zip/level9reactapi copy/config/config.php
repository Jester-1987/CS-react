<?php

// Define configuration options
$allowedOrigins = ['http://localhost:3000']; // Add other allowed origins as needed
$allowedHeaders = ['Content-Type', 'Authorization']; // Add additional headers if required
$allowedMethods = ['GET', 'POST', 'OPTIONS'];

// Get the origin of the request
$origin = isset($_SERVER['HTTP_ORIGIN']) ? $_SERVER['HTTP_ORIGIN'] : '';

// Set CORS headers if the origin is allowed
if (in_array($origin, $allowedOrigins)) {
    header('Access-Control-Allow-Origin: ' . $origin);
    header('Access-Control-Allow-Methods: ' . implode(', ', $allowedMethods));
    header('Access-Control-Allow-Headers: ' . implode(', ', $allowedHeaders));
}

// Handle preflight requests
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    // Stop further processing for preflight requests
    http_response_code(200);
    exit;
}





// OLD CODE
// $allowedOrigins = ['http://localhost:3000'];
// $allowedHeaders = ['Content-Type'];
// $allowedMethods = ['GET', 'POST', 'OPTIONS'];


// $origin = isset($_SERVER['HTTP_ORIGIN']) ? $_SERVER['HTTP_ORIGIN'] : '';
// if (in_array($origin, $allowedOrigins)) {
//     header('Access-Control-Allow-Origin: ' . $origin);
// }

// if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_METHOD'])) {
//     header('Access-Control-Allowed-Methods:' . implode(', ', $allowedMethods));
// }

// if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS'])) {
//     $requestHeaders = explode(',', $_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']);
//     $requestHeaders = array_map('trim', $requestHeaders, $allowedHeaders); 
//     if (count(array_intersect($requestHeaders, $allowedHeaders)) == count ($requestHeaders)) {
//         header('Access-Control-Allow-Headers: ' . implode(', ', $allowedHeaders));
//     }
// }

?>